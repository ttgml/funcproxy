from funcproxy.core.plugin_base import PluginBase
import json

class Plugin(PluginBase):
    def __init__(self):
        print("Runenv Plugin initialized")

    def do_get_user_address(self, parameters) -> str:
        return "青岛"